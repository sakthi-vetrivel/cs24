/*
 * This is a stub header for fact.s
 */
extern int fact(int n);
